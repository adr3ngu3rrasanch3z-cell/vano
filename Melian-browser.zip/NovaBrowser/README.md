# Melian Browser — Android

Browser Android built with Kotlin, Jetpack Compose and Android WebView.

## Build
Requires JDK 17, Gradle 8.9 and Android SDK 35.
Run from this folder:
    gradle :app:assembleDebug

The GitHub Actions workflow builds a debug APK on pushes to `main` or by manual dispatch.

## Current features
- Full-screen illustrated home landscape featuring the user's original Melian horse artwork.
- Search by tapping the home landscape; no permanent address bar on the home screen.
- Sage, sky-blue, blush-pink and cream palette with brief side-only botanical entrance decoration.
- Pixel-art Melian launcher icon and horse-shaped back/forward controls.
- Tab strip with multiple tabs and local persistence of tab URLs across app restarts.
- WebView browsing, back/forward, reload and home controls.

## MVP notes
- Loading animation is intentionally deferred for a later update.
- Tab URLs are restored; live WebView session state, scroll position, history, bookmarks,
  downloads, private browsing, popup handling and production hardening are not implemented.
- JavaScript and DOM storage are enabled; local file/content access is disabled.
