package com.example.novabrowser

import android.content.Context
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import java.util.UUID

const val HOME_URL = "melian://home"

class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    initialUrl: String = HOME_URL
) {
    var url by mutableStateOf(initialUrl)
    var title by mutableStateOf("New tab")
    var progress by mutableStateOf(0)
    var webView: WebView? = null
}

class BrowserState(private val appContext: Context) {
    val tabs = mutableStateListOf<BrowserTab>()
    var activeTabId by mutableStateOf("")
    var addressText by mutableStateOf("")
    var menuExpanded by mutableStateOf(false)

    val activeTab: BrowserTab?
        get() = tabs.firstOrNull { it.id == activeTabId }

    private val prefs = appContext.getSharedPreferences("melian_browser", Context.MODE_PRIVATE)

    init {
        restoreTabs()
    }

    private fun restoreTabs() {
        val count = prefs.getInt("tab_count", 0)
        if (count > 0) {
            repeat(count.coerceAtMost(20)) { index ->
                val url = prefs.getString("tab_$index", HOME_URL) ?: HOME_URL
                tabs.add(BrowserTab(initialUrl = url))
            }
            val active = prefs.getInt("active_index", 0).coerceIn(0, tabs.lastIndex)
            activeTabId = tabs[active].id
            addressText = if (tabs[active].url == HOME_URL) "" else tabs[active].url
        } else {
            createTab()
        }
    }

    private fun persistTabs() {
        prefs.edit().apply {
            putInt("tab_count", tabs.size)
            putInt("active_index", tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0))
            tabs.forEachIndexed { index, tab -> putString("tab_$index", tab.url) }
            apply()
        }
    }

    fun createTab() {
        val tab = BrowserTab()
        tabs.add(tab)
        activeTabId = tab.id
        addressText = ""
        persistTabs()
    }

    fun selectTab(id: String) {
        activeTabId = id
        addressText = tabs.firstOrNull { it.id == id }?.url.orEmpty().takeUnless { it == HOME_URL }.orEmpty()
        persistTabs()
    }

    fun closeTab(id: String) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val tab = tabs[index]
        tab.webView?.stopLoading()
        tab.webView?.destroy()
        tabs.removeAt(index)

        if (tabs.isEmpty()) {
            createTab()
        } else if (activeTabId == id) {
            val next = tabs.getOrNull(index.coerceAtMost(tabs.lastIndex)) ?: tabs.last()
            selectTab(next.id)
        }
        persistTabs()
    }

    fun navigate(raw: String) {
        val tab = activeTab ?: return
        val input = raw.trim()
        if (input.isEmpty()) return

        val destination = when {
            input.startsWith("https://") || input.startsWith("http://") -> input
            input.contains(" ") || !input.contains(".") -> {
                "https://www.google.com/search?q=" + input.replace(" ", "+")
            }
            else -> "https://$input"
        }
        addressText = destination
        tab.url = destination
        tab.title = destination
        tab.webView?.loadUrl(destination)
        persistTabs()
    }

    fun goBack(): Boolean {
        val web = activeTab?.webView ?: return false
        if (web.canGoBack()) {
            web.goBack()
            return true
        }
        return false
    }

    fun goForward() {
        activeTab?.webView?.let { if (it.canGoForward()) it.goForward() }
    }

    fun reload() {
        activeTab?.webView?.reload()
    }

    fun home() {
        val tab = activeTab ?: return
        tab.webView?.stopLoading()
        tab.url = HOME_URL
        tab.title = "Inicio"
        addressText = ""
        persistTabs()
    }

    fun getOrCreateWebView(tab: BrowserTab): WebView {
        val existing = tab.webView
        if (existing != null) return existing

        val web = WebView(appContext)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.setSupportMultipleWindows(false)

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                url?.let {
                    tab.url = it
                    if (activeTabId == tab.id) addressText = it
                }
                tab.progress = 0
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                url?.let {
                    tab.url = it
                    if (activeTabId == tab.id) addressText = it
                    persistTabs()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: tab.url
            }
        }

        tab.webView = web
        return web
    }

    fun dispose() {
        tabs.forEach { it.webView?.destroy() }
        persistTabs()
        tabs.clear()
    }
}
