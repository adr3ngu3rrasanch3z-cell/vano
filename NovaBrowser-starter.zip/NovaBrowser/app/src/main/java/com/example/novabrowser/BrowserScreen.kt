package com.example.novabrowser

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun BrowserScreen(state: BrowserState) {
    val tab = state.activeTab
    BackHandler(enabled = tab?.webView?.canGoBack() == true) {
        state.goBack()
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // DESIGN PLACEHOLDER: replace this entire area with your own address bar.
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = state.addressText,
                onValueChange = { state.addressText = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search or enter address") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { state.navigate(state.addressText) })
            )
            Box {
                IconButton(onClick = { state.menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                }
                DropdownMenu(
                    expanded = state.menuExpanded,
                    onDismissRequest = { state.menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("New tab") },
                        onClick = { state.menuExpanded = false; state.createTab() },
                        leadingIcon = { Icon(Icons.Default.Add, null) }
                    )
                    DropdownMenuItem(
                        text = { Text("Reload") },
                        onClick = { state.menuExpanded = false; state.reload() },
                        leadingIcon = { Icon(Icons.Default.Refresh, null) }
                    )
                    DropdownMenuItem(
                        text = { Text("Home") },
                        onClick = { state.menuExpanded = false; state.home() },
                        leadingIcon = { Icon(Icons.Default.Home, null) }
                    )
                }
            }
        }

        tab?.let { current ->
            if (current.progress in 1..99) {
                LinearProgressIndicator(
                    progress = { current.progress / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            key(current.id) {
                val context = LocalContext.current
                AndroidView(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    factory = {
                        state.getOrCreateWebView(current).apply {
                            if (parent != null) {
                                (parent as? ViewGroup)?.removeView(this)
                            }
                            if (this.url.isNullOrBlank()) {
                                loadUrl("https://www.google.com")
                            } else if (this.url == null) {
                                loadUrl(current.url)
                            }
                        }
                    },
                    update = { }
                )
            }
        } ?: Spacer(modifier = Modifier.weight(1f))

        // DESIGN PLACEHOLDER: tab strip. You can replace its visual appearance.
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            state.tabs.forEach { item ->
                TextButton(onClick = { state.selectTab(item.id) }) {
                    Text(
                        text = (if (item.id == state.activeTabId) "• " else "") +
                            item.title.take(12),
                        maxLines = 1
                    )
                    IconButton(
                        onClick = { state.closeTab(item.id) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close tab")
                    }
                }
            }
            IconButton(onClick = { state.createTab() }) {
                Icon(Icons.Default.Add, contentDescription = "New tab")
            }
        }

        // DESIGN PLACEHOLDER: bottom navigation controls.
        NavigationBar {
            NavigationBarItem(
                selected = false,
                onClick = { state.goBack() },
                icon = { Icon(Icons.Default.ArrowBack, contentDescription = "Back") },
                label = { Text("Back") }
            )
            NavigationBarItem(
                selected = false,
                onClick = { state.goForward() },
                icon = { Icon(Icons.Default.ArrowForward, contentDescription = "Forward") },
                label = { Text("Forward") }
            )
            NavigationBarItem(
                selected = false,
                onClick = { state.home() },
                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                label = { Text("Home") }
            )
            NavigationBarItem(
                selected = false,
                onClick = { state.reload() },
                icon = { Icon(Icons.Default.Refresh, contentDescription = "Reload") },
                label = { Text("Reload") }
            )
            NavigationBarItem(
                selected = false,
                onClick = { /* tab count is visible in the tab strip */ },
                icon = { Icon(Icons.Default.Menu, contentDescription = "Tabs") },
                label = { Text("${state.tabs.size} tabs") }
            )
        }
    }
}
