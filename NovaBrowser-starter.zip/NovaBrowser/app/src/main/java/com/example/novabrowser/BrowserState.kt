package com.example.novabrowser

import android.content.Context
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import java.util.UUID

class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    initialUrl: String = "https://www.google.com"
) {
    var url by mutableStateOf(initialUrl)
    var title by mutableStateOf("New tab")
    var progress by mutableStateOf(0)
    var webView: WebView? = null
}

class BrowserState(private val appContext: Context) {
    val tabs = mutableStateListOf<BrowserTab>()
    var activeTabId by mutableStateOf("")
    var addressText by mutableStateOf("")
    var menuExpanded by mutableStateOf(false)

    val activeTab: BrowserTab?
        get() = tabs.firstOrNull { it.id == activeTabId }

    init {
        createTab()
    }

    fun createTab() {
        val tab = BrowserTab()
        tabs.add(tab)
        activeTabId = tab.id
        addressText = ""
    }

    fun selectTab(id: String) {
        activeTabId = id
        addressText = tabs.firstOrNull { it.id == id }?.url.orEmpty()
    }

    fun closeTab(id: String) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val tab = tabs[index]
        tab.webView?.stopLoading()
        tab.webView?.destroy()
        tabs.removeAt(index)

        if (tabs.isEmpty()) {
            createTab()
        } else if (activeTabId == id) {
            val next = tabs.getOrNull(index.coerceAtMost(tabs.lastIndex)) ?: tabs.last()
            selectTab(next.id)
        }
    }

    fun navigate(raw: String) {
        val tab = activeTab ?: return
        val input = raw.trim()
        if (input.isEmpty()) return

        val destination = when {
            input.startsWith("https://") || input.startsWith("http://") -> input
            input.contains(" ") || !input.contains(".") -> {
                "https://www.google.com/search?q=" + input.replace(" ", "+")
            }
            else -> "https://$input"
        }
        addressText = destination
        tab.url = destination
        tab.webView?.loadUrl(destination)
    }

    fun goBack(): Boolean {
        val web = activeTab?.webView ?: return false
        if (web.canGoBack()) {
            web.goBack()
            return true
        }
        return false
    }

    fun goForward() {
        activeTab?.webView?.let { if (it.canGoForward()) it.goForward() }
    }

    fun reload() {
        activeTab?.webView?.reload()
    }

    fun home() {
        navigate("https://www.google.com")
    }

    fun getOrCreateWebView(tab: BrowserTab): WebView {
        val existing = tab.webView
        if (existing != null) return existing

        val web = WebView(appContext)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.setSupportMultipleWindows(false)

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                url?.let {
                    tab.url = it
                    if (activeTabId == tab.id) addressText = it
                }
                tab.progress = 0
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                url?.let {
                    tab.url = it
                    if (activeTabId == tab.id) addressText = it
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: tab.url
            }
        }

        tab.webView = web
        return web
    }

    fun dispose() {
        tabs.forEach { it.webView?.destroy() }
        tabs.clear()
    }
}
