# Nova Browser — starter project

Android browser starter built with Kotlin, Jetpack Compose and Android WebView.

## Build
Requires JDK 17, Gradle 8.9 and Android SDK 35.
Run:
    gradle :app:assembleDebug

The GitHub Actions workflow builds a debug APK on pushes to `main` or by manual dispatch.
After the workflow completes, download the `nova-browser-debug` artifact from the Actions run.

## Important MVP notes
- This is an initial functional scaffold, not a production browser.
- Tabs each own a WebView instance; closing a tab destroys its WebView.
- History/bookmarks persistence, downloads, private browsing, permissions UI, popup handling,
  file chooser support, and production hardening are not implemented yet.
- JavaScript and DOM storage are enabled for modern sites. File/content access is disabled.
- The initial screen uses intentionally plain placeholder components to make redesign easier.
